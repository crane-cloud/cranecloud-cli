# Configuration file for CraneCloud CLI
import os
# API Base URL
API_BASE_URL = os.getenv('API_BASE_URL')

USER_INFO_URL = {}

